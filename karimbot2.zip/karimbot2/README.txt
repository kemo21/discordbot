1) افتح PowerShell في فولدر المشروع (نفس المكان اللي فيه package.json)
2) انسخ .env.example لملف .env وحط القيم بتاعتك
3) npm i
4) npm run deploy
5) npm start

ملحوظة: Lavalink لازم يكون شغال قبل /play
