const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, StreamType, EndBehaviorType } = require("@discordjs/voice");
const prism = require("prism-media");
const { config } = require("../config/config");
const { translateText } = require("./translate");
const { updateGuild, getGuild } = require("../config/store");

function pcmToWav(pcmBuffer, sampleRate = 48000, channels = 2) {
  const bitsPerSample = 16;
  const byteRate = sampleRate * channels * bitsPerSample / 8;
  const blockAlign = channels * bitsPerSample / 8;
  const dataSize = pcmBuffer.length;

  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16); // PCM
  header.writeUInt16LE(1, 20); // format
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write("data", 36);
  header.writeUInt32LE(dataSize, 40);
  return Buffer.concat([header, pcmBuffer]);
}

async function openaiTranscribe(wavBuffer) {
  if (!config.openai.apiKey) throw new Error("حط OPENAI_API_KEY في .env");

  const form = new FormData();
  form.append("model", config.openai.transcribeModel);
  form.append("file", new Blob([wavBuffer], { type: "audio/wav" }), "audio.wav");

  const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { "Authorization": `Bearer ${config.openai.apiKey}` },
    body: form
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`Transcribe error ${res.status}: ${t.slice(0, 200)}`);
  }
  const json = await res.json();
  return (json.text || "").trim();
}

async function openaiTTSOpus(text) {
  const res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${config.openai.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: config.openai.ttsModel,
      voice: config.openai.ttsVoice,
      input: text,
      format: "opus"
    })
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`TTS error ${res.status}: ${t.slice(0, 200)}`);
  }
  const arr = await res.arrayBuffer();
  return Buffer.from(arr);
}

// Global per-guild sessions
const sessions = new Map(); // guildId -> { connection, player, textChannelId, mode, stop() }

async function startVoiceTranslate(interaction, mode) {
  if (!interaction.inGuild()) throw new Error("لازم سيرفر");
  const member = interaction.member;
  const voice = member.voice?.channel;
  if (!voice) throw new Error("ادخل فويس الأول");

  const guildId = interaction.guild.id;
  if (sessions.has(guildId)) throw new Error("مفعل بالفعل");

  const connection = joinVoiceChannel({
    channelId: voice.id,
    guildId,
    adapterCreator: interaction.guild.voiceAdapterCreator,
    selfDeaf: false,
    selfMute: false
  });

  const player = createAudioPlayer();
  connection.subscribe(player);

  const receiver = connection.receiver;

  let stopped = false;

  async function handleUserStream(userId) {
    if (stopped) return;

    const opusStream = receiver.subscribe(userId, {
      end: { behavior: EndBehaviorType.AfterSilence, duration: 700 }
    });

    // decode opus -> pcm
    const decoder = new prism.opus.Decoder({ frameSize: 960, channels: 2, rate: 48000 });
    const pcmChunks = [];
    let pcmLen = 0;

    const pipeline = opusStream.pipe(decoder);

    const start = Date.now();
    const MAX_MS = 6000;

    await new Promise((resolve) => {
      pipeline.on("data", (chunk) => {
        if (stopped) return;
        pcmChunks.push(chunk);
        pcmLen += chunk.length;
        if (Date.now() - start > MAX_MS) {
          try { opusStream.destroy(); } catch {}
          resolve();
        }
      });
      pipeline.on("end", resolve);
      pipeline.on("close", resolve);
      pipeline.on("error", resolve);
    });

    if (stopped) return;
    if (pcmLen < 48000) return; // ignore very small

    const pcm = Buffer.concat(pcmChunks, pcmLen);
    const wav = pcmToWav(pcm);

    try {
      const text = await openaiTranscribe(wav);
      if (!text) return;

      const translated = await translateText(text, mode === "to_en" ? "to_en" : "to_ar");

      // send in text channel too
      const ch = interaction.guild.channels.cache.get(getGuild(guildId).vctranslate.textChannelId || interaction.channelId);
      if (ch) {
        await ch.send({
          content: `🗣️ **${interaction.guild.members.cache.get(userId)?.displayName || userId}**: ${translated}`
        }).catch(() => null);
      }

      // speak in voice with opus (no ffmpeg)
      const opusBuf = await openaiTTSOpus(translated);
      const { Readable } = require("stream");
      const stream = Readable.from(opusBuf);
      const resource = createAudioResource(stream, { inputType: StreamType.OggOpus });
      player.play(resource);
    } catch (e) {
      // ignore
    }
  }

  receiver.speaking.on("start", (userId) => {
    // تجاهل البوت
    if (userId === interaction.client.user.id) return;
    handleUserStream(userId);
  });

  const stop = async () => {
    stopped = true;
    try { connection.destroy(); } catch {}
    sessions.delete(guildId);
    updateGuild(guildId, (g) => { g.vctranslate.enabled = false; });
  };

  sessions.set(guildId, { connection, player, textChannelId: interaction.channelId, mode, stop });
  updateGuild(guildId, (g) => { g.vctranslate.enabled = true; g.vctranslate.mode = mode; g.vctranslate.textChannelId = interaction.channelId; });

  return true;
}

async function stopVoiceTranslate(interaction) {
  if (!interaction.inGuild()) return false;
  const s = sessions.get(interaction.guild.id);
  if (!s) return false;
  await s.stop();
  return true;
}

module.exports = { startVoiceTranslate, stopVoiceTranslate };
