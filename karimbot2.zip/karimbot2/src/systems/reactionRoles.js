const { updateGuild, getGuild } = require("../config/store");

function setupReactionRoles(client) {
  client.on("messageReactionAdd", async (reaction, user) => {
    if (user.bot) return;
    try { if (reaction.partial) await reaction.fetch(); } catch { return; }
    if (!reaction.message.guild) return;
    const guildId = reaction.message.guild.id;
    const g = getGuild(guildId);
    const map = g.reactionRoles[reaction.message.id];
    if (!map) return;

    const emojiKey = reaction.emoji.id ? `${reaction.emoji.name}:${reaction.emoji.id}` : reaction.emoji.name;
    const roleId = map[emojiKey];
    if (!roleId) return;

    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    await member.roles.add(roleId).catch(() => null);
  });

  client.on("messageReactionRemove", async (reaction, user) => {
    if (user.bot) return;
    try { if (reaction.partial) await reaction.fetch(); } catch { return; }
    if (!reaction.message.guild) return;
    const guildId = reaction.message.guild.id;
    const g = getGuild(guildId);
    const map = g.reactionRoles[reaction.message.id];
    if (!map) return;

    const emojiKey = reaction.emoji.id ? `${reaction.emoji.name}:${reaction.emoji.id}` : reaction.emoji.name;
    const roleId = map[emojiKey];
    if (!roleId) return;

    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    await member.roles.remove(roleId).catch(() => null);
  });
}

function addReactionRole(guildId, messageId, emojiKey, roleId) {
  updateGuild(guildId, (g) => {
    if (!g.reactionRoles[messageId]) g.reactionRoles[messageId] = {};
    g.reactionRoles[messageId][emojiKey] = roleId;
  });
}

module.exports = { setupReactionRoles, addReactionRole };
