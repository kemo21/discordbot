const { createAudioPlayer, joinVoiceChannel, getVoiceConnection, AudioPlayerStatus, NoSubscriberBehavior, createAudioResource, StreamType } = require("@discordjs/voice");
const { NodeManager } = require("lavalink-client");
const { config } = require("../config/config");

// Music manager singleton
function createMusicManager(client) {
  const nodes = [{
    id: "main",
    host: config.lavalink.host,
    port: config.lavalink.port,
    password: config.lavalink.password,
    secure: config.lavalink.secure
  }];

 import { NodeManager } from "lavalink-client";

export function createMusicManager(client) {
  const nodes = [
    {
      id: "main",
      host: process.env.LAVALINK_HOST || "127.0.0.1",
      port: Number(process.env.LAVALINK_PORT || 2333),
      password: process.env.LAVALINK_PASS || "youshallnotpass",
      secure: false,
    },
  ];

  const manager = new NodeManager({
    nodes,
    sendToShard: (guildId, payload) => {
      const guild = client.guilds.cache.get(guildId);
      guild?.shard?.send(payload);
    },
    client: {
      id: process.env.CLIENT_ID,
      username: client.user?.username ?? "bot",
    },
  });

  manager.init(client);
  return manager;
}