const { EmbedBuilder, AuditLogEvent } = require("discord.js");
const { getGuild } = require("../config/store");

async function sendLog(guild, embed) {
  const g = getGuild(guild.id);
  const channelId = g.settings.logChannelId;
  if (!channelId) return;
  const ch = guild.channels.cache.get(channelId);
  if (!ch) return;
  try { await ch.send({ embeds: [embed] }); } catch {}
}

function setupLogs(client) {
  client.on("messageDelete", async (msg) => {
    if (!msg.guild || !msg.author) return;
    const embed = new EmbedBuilder()
      .setColor(0xe67e22)
      .setTitle("🗑️ Message Deleted")
      .addFields(
        { name: "User", value: `${msg.author.tag} (${msg.author.id})`, inline: false },
        { name: "Channel", value: `${msg.channel}`, inline: true },
        { name: "Content", value: (msg.content || "[no text]").slice(0, 1000), inline: false }
      )
      .setTimestamp();
    await sendLog(msg.guild, embed);
  });

  client.on("messageUpdate", async (oldMsg, newMsg) => {
    if (!newMsg.guild || !newMsg.author) return;
    if (oldMsg.content === newMsg.content) return;
    const embed = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle("✏️ Message Edited")
      .addFields(
        { name: "User", value: `${newMsg.author.tag} (${newMsg.author.id})`, inline: false },
        { name: "Channel", value: `${newMsg.channel}`, inline: true },
        { name: "Before", value: (oldMsg.content || "[no text]").slice(0, 800), inline: false },
        { name: "After", value: (newMsg.content || "[no text]").slice(0, 800), inline: false }
      )
      .setTimestamp();
    await sendLog(newMsg.guild, embed);
  });

  client.on("guildMemberAdd", async (member) => {
    const embed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle("✅ Member Joined")
      .setDescription(`${member.user.tag} (${member.id})`)
      .setTimestamp();
    await sendLog(member.guild, embed);
  });

  client.on("guildMemberRemove", async (member) => {
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle("❌ Member Left")
      .setDescription(`${member.user.tag} (${member.id})`)
      .setTimestamp();
    await sendLog(member.guild, embed);
  });
}

module.exports = { setupLogs, sendLog };
