const { PermissionsBitField, ChannelType, EmbedBuilder } = require("discord.js");
const { updateGuild, getGuild } = require("../config/store");
const { sendLog } = require("./logs");

async function ensureTicketCategory(guild) {
  const g = getGuild(guild.id);
  let catId = g.tickets.categoryId;
  let cat = catId ? guild.channels.cache.get(catId) : null;
  if (!cat) {
    cat = await guild.channels.create({
      name: "Tickets",
      type: ChannelType.GuildCategory
    });
    updateGuild(guild.id, (gg) => { gg.tickets.categoryId = cat.id; });
  }
  return cat;
}

async function openTicket(interaction, subject) {
  const guild = interaction.guild;
  const member = interaction.member;

  const cat = await ensureTicketCategory(guild);

  const g = getGuild(guild.id);
  const next = (g.tickets.counter || 0) + 1;
  updateGuild(guild.id, (gg) => { gg.tickets.counter = next; });

  const channel = await guild.channels.create({
    name: `ticket-${next}`,
    type: ChannelType.GuildText,
    parent: cat.id,
    permissionOverwrites: [
      { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: member.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
      { id: interaction.client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels] }
    ]
  });

  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(0x9b59b6)
        .setTitle("🎫 Ticket Opened")
        .setDescription(`Owner: ${interaction.user}\nSubject: **${subject || "بدون"}**\nاكتب مشكلتك هنا.`)
    ],
    allowedMentions: { users: [interaction.user.id] }
  });

  const log = new EmbedBuilder().setColor(0x9b59b6).setTitle("🎫 Ticket Opened").setDescription(`${interaction.user.tag} -> ${channel}`).setTimestamp();
  await sendLog(guild, log);

  return channel;
}

async function closeTicket(interaction) {
  const ch = interaction.channel;
  if (!ch || !interaction.guild) return false;
  if (!ch.name.startsWith("ticket-")) return false;

  const log = new EmbedBuilder().setColor(0x95a5a6).setTitle("🎫 Ticket Closed").setDescription(`${interaction.user.tag} closed ${ch.name}`).setTimestamp();
  await sendLog(interaction.guild, log);

  await ch.delete("Ticket closed").catch(() => null);
  return true;
}

module.exports = { openTicket, closeTicket };
