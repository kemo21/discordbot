const { AttachmentBuilder } = require("discord.js");
const { updateGuild, getGuild } = require("../config/store");

function xpForLevel(level) {
  return 5 * (level ** 2) + 50 * level + 100;
}

function setupLevels(client) {
  client.on("messageCreate", async (msg) => {
    if (!msg.guild || msg.author.bot) return;

    // XP بسيط
    updateGuild(msg.guild.id, (g) => {
      if (!g.levels.users[msg.author.id]) g.levels.users[msg.author.id] = { xp: 0, level: 0 };
      const u = g.levels.users[msg.author.id];
      u.xp += 5;

      // level up
      let needed = xpForLevel(u.level);
      while (u.xp >= needed) {
        u.xp -= needed;
        u.level += 1;
        needed = xpForLevel(u.level);
      }
    });
  });
}

function getUserStats(guildId, userId) {
  const g = getGuild(guildId);
  return g.levels.users[userId] || { xp: 0, level: 0 };
}

function getLeaderboard(guildId) {
  const g = getGuild(guildId);
  const entries = Object.entries(g.levels.users).map(([id, v]) => ({ id, ...v }));
  entries.sort((a, b) => (b.level - a.level) || (b.xp - a.xp));
  return entries.slice(0, 10);
}

module.exports = { setupLevels, getUserStats, getLeaderboard };
