const { config } = require("../config/config");

async function openaiJson(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${config.openai.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`OpenAI error ${res.status}: ${t.slice(0, 200)}`);
  }
  return res.json();
}

async function translateText(text, target) {
  if (!config.openai.apiKey) throw new Error("حط OPENAI_API_KEY في .env");
  const prompt = target === "to_en"
    ? `Translate the following Arabic (Egyptian dialect if any) to natural English. Keep meaning. Text:\n${text}`
    : `ترجم النص التالي لأي لغة كانت إلى عربي مصري عامي طبيعي وواضح بدون فصحى زيادة. النص:\n${text}`;

  // responses API (modern) - بس نخليه بسيط: chat.completions برضه شغال على اغلب الحسابات
  const json = await openaiJson("https://api.openai.com/v1/chat/completions", {
    model: config.openai.textModel,
    messages: [
      { role: "system", content: "You are a translation engine. Output only the translated text." },
      { role: "user", content: prompt }
    ],
    temperature: 0.2
  });
  const out = json.choices?.[0]?.message?.content?.trim();
  if (!out) throw new Error("فشل الترجمة");
  return out;
}

module.exports = { translateText };
