const { PermissionsBitField, EmbedBuilder } = require("discord.js");
const { sendLog } = require("./logs");

const urlRegex = /(https?:\/\/[^\s]+)/i;

function setupAutomod(client) {
  const rate = new Map(); // userId -> {count, ts}

  client.on("messageCreate", async (msg) => {
    if (!msg.guild || msg.author.bot) return;

    // anti-link (بدون AutoMod)
    const member = msg.member;
    const canBypass = member?.permissions?.has(PermissionsBitField.Flags.ManageMessages);
    if (!canBypass && urlRegex.test(msg.content)) {
      try { await msg.delete(); } catch {}
      try { await msg.channel.send({ content: `🚫 ممنوع لينكات يا ${msg.author}` , allowedMentions: { users: [msg.author.id] }}); } catch {}
      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle("🚫 Anti-Link")
        .setDescription(`Deleted link from ${msg.author.tag} in ${msg.channel}`)
        .setTimestamp();
      await sendLog(msg.guild, embed);
      return;
    }

    // anti-spam (rate limit بسيط)
    const now = Date.now();
    const key = `${msg.guild.id}:${msg.author.id}`;
    const v = rate.get(key) || { count: 0, ts: now };
    if (now - v.ts > 5000) { v.count = 0; v.ts = now; }
    v.count += 1;
    rate.set(key, v);

    if (v.count >= 7 && !canBypass) {
      // timeout 10 minutes لو البوت معاه صلاحية
      try {
        if (member && member.moderatable) {
          await member.timeout(10 * 60 * 1000, "Spam");
        }
      } catch {}
      try { await msg.channel.send({ content: `⛔ سبام يا ${msg.author}.. تم كتمك 10 دقايق`, allowedMentions: { users: [msg.author.id] }}); } catch {}
      const embed = new EmbedBuilder()
        .setColor(0xe67e22)
        .setTitle("⛔ Anti-Spam")
        .setDescription(`Timeout ${msg.author.tag} for spam in ${msg.channel}`)
        .setTimestamp();
      await sendLog(msg.guild, embed);

      v.count = 0;
      v.ts = now;
      rate.set(key, v);
    }
  });
}

module.exports = { setupAutomod };
