const { REST, Routes } = require("discord.js");
const { config } = require("./config/config");

// dummy client id only for building commands list (music doesn't need runtime data)
const { buildCommands } = require("./commands");
const fakeMusicManager = { players: new Map() };
const commands = buildCommands(fakeMusicManager).map(c => c.data.toJSON());

async function main() {
  const rest = new REST({ version: "10" }).setToken(config.token);
  console.log("Deploying commands...");
  await rest.put(
    Routes.applicationGuildCommands(config.clientId, config.guildId),
    { body: commands }
  );
  console.log("✅ Guild commands deployed.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
