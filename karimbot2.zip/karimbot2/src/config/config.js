const fs = require("fs");
const path = require("path");

// minimal .env loader (عشان ما نعتمدش على dotenv و ES module مشاكل)
function loadEnv() {
  const envPath = path.join(process.cwd(), ".env");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    if (!line || line.trim().startsWith("#")) continue;
    const idx = line.indexOf("=");
    if (idx === -1) continue;
    const k = line.slice(0, idx).trim();
    const v = line.slice(idx + 1).trim();
    if (!process.env[k]) process.env[k] = v;
  }
}
loadEnv();

function must(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

const config = {
  token: must("DISCORD_TOKEN"),
  clientId: must("CLIENT_ID"),
  guildId: must("GUILD_ID"),

  welcomeChannelId: process.env.WELCOME_CHANNEL_ID || null,
  logChannelId: process.env.LOG_CHANNEL_ID || null,

  lavalink: {
    host: process.env.LAVALINK_HOST || "127.0.0.1",
    port: Number(process.env.LAVALINK_PORT || 2333),
    password: process.env.LAVALINK_PASS || "youshallnotpass",
    secure: false
  },

  openai: {
    apiKey: process.env.OPENAI_API_KEY || "",
    textModel: process.env.OPENAI_TEXT_MODEL || "gpt-4o-mini",
    ttsModel: process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts",
    ttsVoice: process.env.OPENAI_TTS_VOICE || "alloy",
    transcribeModel: process.env.OPENAI_TRANSCRIBE_MODEL || "gpt-4o-mini-transcribe"
  }
};

module.exports = { config };
