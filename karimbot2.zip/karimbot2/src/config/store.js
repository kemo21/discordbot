const fs = require("fs");
const path = require("path");

const DATA_PATH = path.join(process.cwd(), "data.json");

function read() {
  try {
    return JSON.parse(fs.readFileSync(DATA_PATH, "utf8"));
  } catch {
    return { guilds: {} };
  }
}

function write(data) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), "utf8");
}

function ensureGuild(data, guildId) {
  if (!data.guilds[guildId]) {
    data.guilds[guildId] = {
      settings: {
        welcomeChannelId: null,
        logChannelId: null,
        welcomeGifUrl: "https://media.giphy.com/media/3o7TKMt1VVNkHV2PaE/giphy.gif"
      },
      reactionRoles: {}, // messageId -> { emoji -> roleId }
      tickets: { categoryId: null, counter: 0 },
      levels: { users: {} }, // userId -> { xp, level }
      vctranslate: { enabled: false, mode: "to_ar", textChannelId: null }
    };
  }
  return data.guilds[guildId];
}

function getGuild(guildId) {
  const data = read();
  const g = ensureGuild(data, guildId);
  write(data);
  return g;
}

function updateGuild(guildId, mutator) {
  const data = read();
  const g = ensureGuild(data, guildId);
  mutator(g, data);
  write(data);
  return g;
}

module.exports = { read, write, getGuild, updateGuild };
