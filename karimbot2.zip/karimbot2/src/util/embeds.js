const { EmbedBuilder } = require("discord.js");

function info(title, desc) {
  return new EmbedBuilder().setTitle(title).setDescription(desc).setColor(0x2ecc71);
}
function warn(title, desc) {
  return new EmbedBuilder().setTitle(title).setDescription(desc).setColor(0xf1c40f);
}
function err(title, desc) {
  return new EmbedBuilder().setTitle(title).setDescription(desc).setColor(0xe74c3c);
}

module.exports = { info, warn, err };
