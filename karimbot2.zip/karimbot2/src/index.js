const { Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { config } = require("./config/config");
const { getGuild } = require("./config/store");

const { setupAutomod } = require("./systems/automod");
const { setupLogs } = require("./systems/logs");
const { setupLevels } = require("./systems/levels");
const { setupReactionRoles } = require("./systems/reactionRoles");
const { createMusicManager } = require("./systems/music");
const { buildCommands } = require("./commands");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});

let musicManager;

client.once("ready", async () => {
  console.log(`✅ Logged in as ${client.user.tag}`);

  // init music after ready (fix nodes undefined)
  musicManager = createMusicManager(client);
  await musicManager.init(client.user.id);

  console.log("✅ Music system ready.");
});

setupAutomod(client);
setupLogs(client);
setupLevels(client);
setupReactionRoles(client);

// Welcome + auto role Loyal
client.on("guildMemberAdd", async (member) => {
  // ensure Loyal role exists and yellow
  let role = member.guild.roles.cache.find(r => r.name.toLowerCase() === "loyal");
  if (!role) {
    role = await member.guild.roles.create({
      name: "Loyal",
      color: 0xF1C40F,
      permissions: []
    }).catch(() => null);
  } else {
    // keep it yellow + no perms
    try { await role.edit({ color: 0xF1C40F, permissions: [] }); } catch {}
  }
  if (role) await member.roles.add(role).catch(() => null);

  const g = getGuild(member.guild.id);
  const welcomeChannelId = g.settings.welcomeChannelId || config.welcomeChannelId;
  if (!welcomeChannelId) return;
  const ch = member.guild.channels.cache.get(welcomeChannelId);
  if (!ch) return;

  const gif = g.settings.welcomeGifUrl;
  const embed = new EmbedBuilder()
    .setColor(0xF1C40F)
    .setTitle("☠️ Welcome to the Dark Side ☠️")
    .setDescription(`يا أهلا بيك يا **${member.displayName}**`)
    .setImage(gif)
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: "System: Welcome" });

  // mention بدون ما نكتب @ داخل النص (منشن فعلي)
  await ch.send({ content: `${member}`, embeds: [embed], allowedMentions: { users: [member.id] } }).catch(() => null);
});

// Interactions routing
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  if (!musicManager) {
    // allow ping/setup even before music
    if (interaction.commandName !== "ping" && interaction.commandName !== "setup") {
      return interaction.reply({ content: "البوت لسه بيجهز.. جرب تاني.", ephemeral: true }).catch(()=>null);
    }
  }

  const commands = buildCommands(musicManager || { players: new Map() });
  const cmd = commands.find(c => c.data.name === interaction.commandName);
  if (!cmd) return;

  try {
    await cmd.execute(interaction);
  } catch (e) {
    const msg = `❌ Error: ${e.message || e}`;
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(msg).catch(()=>null);
    } else {
      await interaction.reply({ content: msg, ephemeral: true }).catch(()=>null);
    }
  }
});

client.login(config.token);
