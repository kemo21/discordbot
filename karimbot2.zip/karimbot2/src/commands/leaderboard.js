const { SlashCommandBuilder } = require("discord.js");
const { getLeaderboard } = require("../systems/levels");

module.exports = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("Top levels"),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const top = getLeaderboard(interaction.guild.id);
    if (!top.length) return interaction.reply({ content: "لسه مفيش.", ephemeral: true });
    const lines = await Promise.all(top.map(async (u, i) => {
      const m = await interaction.guild.members.fetch(u.id).catch(() => null);
      const name = m?.displayName || u.id;
      return `#${i+1} **${name}** — L${u.level} (xp ${u.xp})`;
    }));
    return interaction.reply({ content: "🏅 Leaderboard:\n" + lines.join("\n") });
  }
};
