const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { updateGuild } = require("../config/store");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Setup channels")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s =>
      s.setName("welcome")
        .setDescription("Set welcome channel + gif")
        .addChannelOption(o => o.setName("channel").setDescription("Channel").setRequired(true))
        .addStringOption(o => o.setName("gif").setDescription("GIF URL").setRequired(false))
    )
    .addSubcommand(s =>
      s.setName("logs")
        .setDescription("Set logs channel")
        .addChannelOption(o => o.setName("channel").setDescription("Channel").setRequired(true))
    ),

  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === "welcome") {
      const ch = interaction.options.getChannel("channel", true);
      const gif = interaction.options.getString("gif");
      updateGuild(interaction.guild.id, (g) => {
        g.settings.welcomeChannelId = ch.id;
        if (gif) g.settings.welcomeGifUrl = gif;
      });
      return interaction.reply({ content: "✅ Setup saved.", ephemeral: true });
    }
    if (sub === "logs") {
      const ch = interaction.options.getChannel("channel", true);
      updateGuild(interaction.guild.id, (g) => { g.settings.logChannelId = ch.id; });
      return interaction.reply({ content: "✅ Logs channel saved.", ephemeral: true });
    }
  }
};
