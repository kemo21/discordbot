const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { startVoiceTranslate, stopVoiceTranslate } = require("../systems/voiceTranslate");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("vctranslate")
    .setDescription("Voice translate (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName("start").setDescription("Start voice translate")
      .addStringOption(o => o.setName("mode").setDescription("to_ar / to_en").setRequired(true).addChoices(
        { name: "Any language -> Arabic (Egyptian)", value: "to_ar" },
        { name: "Arabic -> English", value: "to_en" }
      )))
    .addSubcommand(s => s.setName("stop").setDescription("Stop voice translate")),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    try {
      if (sub === "start") {
        const mode = interaction.options.getString("mode", true);
        await startVoiceTranslate(interaction, mode);
        await interaction.editReply("✅ شغال. (البوت هيسجل صوت المتكلمين ويترجمه)");
      } else {
        const ok = await stopVoiceTranslate(interaction);
        await interaction.editReply(ok ? "🛑 وقف." : "مش شغال.");
      }
    } catch (e) {
      await interaction.editReply(`❌ ${e.message || e}`);
    }
  }
};
