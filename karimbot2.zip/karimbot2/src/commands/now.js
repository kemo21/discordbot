const { SlashCommandBuilder } = require("discord.js");

module.exports = (musicManager) => ({
  data: new SlashCommandBuilder().setName("now").setDescription("Now playing"),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const player = musicManager.players.get(interaction.guild.id);
    const cur = player?.queue?.current;
    if (!cur) return interaction.reply({ content: "مفيش حاجة شغالة.", ephemeral: true });
    return interaction.reply({ content: `🎶 Now: **${cur.info.title}**` });
  }
});
