const ping = require("./ping");
const setup = require("./setup");
const rr = require("./rr");
const ticket = require("./ticket");
const rank = require("./rank");
const leaderboard = require("./leaderboard");
const translate = require("./translate");
const vctranslate = require("./vctranslate");
const say = require("./say");

// music commands are factories
const playFactory = require("./play");
const nowFactory = require("./now");
const skipFactory = require("./skip");
const stopFactory = require("./stop");
const queueFactory = require("./queue");

function buildCommands(musicManager) {
  return [
    ping,
    setup,
    rr,
    ticket,
    rank,
    leaderboard,
    translate,
    vctranslate,
    say,
    playFactory(musicManager),
    nowFactory(musicManager),
    skipFactory(musicManager),
    stopFactory(musicManager),
    queueFactory(musicManager)
  ];
}

module.exports = { buildCommands };
