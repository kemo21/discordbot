const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("say")
    .setDescription("Make the bot send a message (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption(o => o.setName("channel").setDescription("Channel").setRequired(true))
    .addStringOption(o => o.setName("message").setDescription("Message").setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const ch = interaction.options.getChannel("channel", true);
    const msg = interaction.options.getString("message", true);
    await ch.send({ content: msg });
    return interaction.reply({ content: "✅ Sent.", ephemeral: true });
  }
};
