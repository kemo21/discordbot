const { SlashCommandBuilder } = require("discord.js");
const { play } = require("../systems/music");

module.exports = (musicManager) => ({
  data: new SlashCommandBuilder()
    .setName("play")
    .setDescription("Play a song (Lavalink)")
    .addStringOption(o => o.setName("query").setDescription("Song name or link").setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const query = interaction.options.getString("query", true);
    await interaction.deferReply(); // مهم عشان ميبقاش Application did not respond
    try {
      const track = await play(musicManager, interaction, query);
      await interaction.editReply(`🎵 شغال: **${track.info.title}**`);
    } catch (e) {
      await interaction.editReply(`❌ حصل Error: ${e.message || e}`);
    }
  }
});
