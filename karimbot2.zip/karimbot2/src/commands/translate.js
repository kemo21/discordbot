const { SlashCommandBuilder } = require("discord.js");
const { translateText } = require("../systems/translate");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("translate")
    .setDescription("Translate text (Any->Egyptian Arabic OR Arabic->English)")
    .addStringOption(o => o.setName("mode").setDescription("to_ar or to_en").setRequired(true).addChoices(
      { name: "Any language -> Arabic (Egyptian)", value: "to_ar" },
      { name: "Arabic -> English", value: "to_en" }
    ))
    .addStringOption(o => o.setName("text").setDescription("Text").setRequired(true)),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    try {
      const mode = interaction.options.getString("mode", true);
      const text = interaction.options.getString("text", true);
      const out = await translateText(text, mode);
      await interaction.editReply(out.slice(0, 1900));
    } catch (e) {
      await interaction.editReply(`❌ ${e.message || e}`);
    }
  }
};
