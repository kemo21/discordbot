const { SlashCommandBuilder } = require("discord.js");
const { getUserStats, getLeaderboard } = require("../systems/levels");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("Show your rank")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(false)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const user = interaction.options.getUser("user") || interaction.user;
    const st = getUserStats(interaction.guild.id, user.id);
    return interaction.reply({ content: `🏆 ${user.username}: Level **${st.level}** | XP **${st.xp}**`, ephemeral: true });
  }
};
