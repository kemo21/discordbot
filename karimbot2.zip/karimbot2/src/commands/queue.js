const { SlashCommandBuilder } = require("discord.js");

module.exports = (musicManager) => ({
  data: new SlashCommandBuilder().setName("queue").setDescription("Show queue"),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const player = musicManager.players.get(interaction.guild.id);
    if (!player || (!player.queue.current && player.queue.tracks.length === 0)) {
      return interaction.reply({ content: "الQueue فاضي.", ephemeral: true });
    }
    const cur = player.queue.current;
    const next = player.queue.tracks.slice(0, 10).map((t, i) => `${i+1}) ${t.info.title}`).join("\n");
    return interaction.reply({ content: `🎶 Now: **${cur?.info?.title || "—"}**\n\n📜 Next:\n${next || "—"}` });
  }
});
