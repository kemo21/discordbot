const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { addReactionRole } = require("../systems/reactionRoles");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rr")
    .setDescription("Reaction roles")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(s => s
      .setName("add")
      .setDescription("Link emoji to role on a message")
      .addStringOption(o => o.setName("message_id").setDescription("Message ID").setRequired(true))
      .addStringOption(o => o.setName("emoji").setDescription("Emoji (😀 or name:id)").setRequired(true))
      .addRoleOption(o => o.setName("role").setDescription("Role").setRequired(true))
    ),

  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === "add") {
      const mid = interaction.options.getString("message_id", true);
      const emoji = interaction.options.getString("emoji", true);
      const role = interaction.options.getRole("role", true);

      addReactionRole(interaction.guild.id, mid, emoji, role.id);

      // try add reaction
      try {
        const msg = await interaction.channel.messages.fetch(mid);
        const parsed = emoji.includes(":") ? `<:${emoji}>` : emoji;
        await msg.react(parsed);
      } catch {}

      return interaction.reply({ content: "✅ Reaction role added.", ephemeral: true });
    }
  }
};
