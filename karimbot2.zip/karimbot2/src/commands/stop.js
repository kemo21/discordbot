const { SlashCommandBuilder } = require("discord.js");

module.exports = (musicManager) => ({
  data: new SlashCommandBuilder().setName("stop").setDescription("Stop & leave"),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const player = musicManager.players.get(interaction.guild.id);
    if (!player) return interaction.reply({ content: "مفيش بلاير.", ephemeral: true });
    await player.destroy().catch(()=>null);
    return interaction.reply({ content: "⏹️ Stop." });
  }
});
