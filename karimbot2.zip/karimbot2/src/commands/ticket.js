const { SlashCommandBuilder } = require("discord.js");
const { openTicket, closeTicket } = require("../systems/tickets");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Tickets system")
    .addSubcommand(s => s.setName("open").setDescription("Open ticket").addStringOption(o=>o.setName("subject").setDescription("Subject").setRequired(false)))
    .addSubcommand(s => s.setName("close").setDescription("Close ticket")),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: "Server only", ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === "open") {
      await interaction.deferReply({ ephemeral: true });
      const subject = interaction.options.getString("subject") || "";
      const ch = await openTicket(interaction, subject);
      return interaction.editReply(`✅ Ticket اتفتح: ${ch}`);
    }
    if (sub === "close") {
      await interaction.deferReply({ ephemeral: true });
      const ok = await closeTicket(interaction);
      if (!ok) return interaction.editReply("❌ ده مش تيكت.");
    }
  }
};
